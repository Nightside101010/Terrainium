Terrainium is a project to bring real - high quality - map data into KSP. The inital goal is to recreate real launch sites and place them on Kerbin, at real life latitudes.

Digital Elevation Map data is from the U.S. Geological Survey Department of the Interior/USGS which is distributed as Public Domain.


v 0.1 	- Mahia Launch Complex 1 
	-The first release of Terrainium brings the home of RocketLab's Electron Rocket to KSP.